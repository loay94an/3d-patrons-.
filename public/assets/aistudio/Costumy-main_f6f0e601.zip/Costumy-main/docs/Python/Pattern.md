

::: costumy.classes.Pattern