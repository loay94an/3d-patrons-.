import React, { useState, useEffect } from 'react';
import { Moon, Sun, DraftingCompass, Info, Copy, Check, FileSpreadsheet, RotateCcw, FileText } from 'lucide-react';
import * as XLSX from 'xlsx';
import { 
  AppState, Gender, SizeSystem, Unit, GarmentType, School, FabricType, SleeveType,
  getSizeList, mapSizeBySystem, getMeasurements, computePatternValues
} from '../lib/pattern-logic';
import { PatternVisualizer } from './PatternVisualizer';
import { PWAInstallButton } from './PWAInstallButton';
import { OfflineIndicator } from './OfflineIndicator';
import { PdfExportModal } from './PdfExportModal';
import { cn } from '../lib/utils';

const detailedNames = ["عرض الظهر","طول الكتف","طول الظهر","طول الكم","محيط الذراع","محيط الأسوارة","محيط الرقبة","محيط الصدر","محيط الخصر","محيط الورك","المسافة من الخصر إلى الورك","المسافة من الخصر إلى الركبة","طول الساق من الخصر إلى أسفل القدم","طول التنورة","طول الصدر (من أعلى الكتف مروراً فوق الصدر)","محيط الإبط (دوران الإبط)","المسافة من الخصر إلى الإبط","المسافة من أعلى الكتف إلى الثدي","المسافة بين الثديين","محيط الفخذ","محيط الركبة","محيط الكاحل","ارتفاع السرج","طول الجنب"];
const detailedHelps = ["يقاس أفقياً من منتصف الظهر بين الإبطين.","من نقطة الرقبة إلى طرف الكتف.","من الفقرة السابعة إلى خط الخصر.","من طرف الكتف إلى الرسغ.","حول أوسع نقطة في الذراع.","حول الرسغ.","حول قاعدة الرقبة.","حول أوسع نقطة في الصدر.","حول أضيق نقطة.","حول أوسع نقطة في الأرداف.","عمودياً من الخصر إلى الورك.","عمودياً إلى منتصف الركبة.","من الخصر إلى الأرض.","من الخصر إلى الطول المطلوب.","من الكتف إلى أعلى الصدر.","حول الإبط عند خط الصدر.","عمودياً إلى الإبط.","من الكتف إلى أعلى الصدر.","أفقياً بين نقطتي الصدر.","حول أوسع نقطة في الفخذ.","حول الركبة.","حول الكاحل.","من الخصر إلى المقعد.","من الإبط إلى الخصر."];
const patternNames = ["طول الظهر","عرض الظهر (نصف)","طول الكتف","ميلان الكتف","ربع محيط الرقبة","عرض حفرة الرقبة الأمامية","عرض حفرة الرقبة الخلفية","نزول الرقبة الأمامية","نزول الرقبة الخلفية","طول حردة الإبط (تقديري)","عمق حردة الإبط","ربع محيط الصدر","عرض الصدر الأمامي","عرض الصدر الخلفي","ربع محيط الخصر","ربع محيط الورك","ارتفاع الورك","طول الصدر","المسافة من الخصر إلى الإبط","المسافة بين الثديين","طول البنطلون","طول التنورة","ربع محيط الفخذ","ربع محيط الركبة","ربع محيط الكاحل","ارتفاع السرج","عرض خط السرج الأمامي","عرض خط السرج الخلفي","طول الساق","المسافة من الخصر إلى الركبة","طول الكم","نصف محيط الذراع","ارتفاع رأس الكم","نصف عرض الكم","نصف محيط الأسوارة","طول الرسغ إلى المرفق","طول المرفق إلى الكتف"];

const defaultState: AppState = {
  gender: 'women',
  system: 'eu',
  unit: 'cm',
  garment: 'blouse',
  school: 'italian',
  sleeve: 'basic',
  fabric: 'woven',
  stretchPercent: 15,
  size: 38,
  includeSeam: true,
  useCustomMode: false,
  customMeasurements: {}
};

export default function PatternApp() {
  const [state, setState] = useState<AppState>(defaultState);
  const [darkMode, setDarkMode] = useState(false);
  const [activeTab, setActiveTab] = useState<'visualizer' | 'measurements' | 'instructions'>('visualizer');
  const [copied, setCopied] = useState(false);
  const [showPdfModal, setShowPdfModal] = useState(false);

  useEffect(() => {
    try {
      const savedTheme = localStorage.getItem('theme');
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const initialDark = savedTheme ? savedTheme === 'dark' : prefersDark;
      setDarkMode(initialDark);
      if (initialDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    } catch (e) {
      // Fallback
    }
  }, []);

  const toggleDark = () => {
    const nextDark = !darkMode;
    setDarkMode(nextDark);
    if (nextDark) {
      document.documentElement.classList.add('dark');
      try {
        localStorage.setItem('theme', 'dark');
      } catch (e) {}
      const meta = document.getElementById('theme-color-meta');
      if (meta) meta.setAttribute('content', '#0f172a');
    } else {
      document.documentElement.classList.remove('dark');
      try {
        localStorage.setItem('theme', 'light');
      } catch (e) {}
      const meta = document.getElementById('theme-color-meta');
      if (meta) meta.setAttribute('content', '#2563eb');
    }
  };

  const updateState = (updates: Partial<AppState>) => {
    setState(prev => {
      const next = { ...prev, ...updates };
      // Reset size if gender changes
      if (updates.gender && updates.gender !== prev.gender) {
        next.size = getSizeList(updates.gender as Gender)[0];
      }
      return next;
    });
  };

  const { values: patternValues, meas, ease, seam, s: schoolValues } = computePatternValues(state);

  const formatDim = (v: number | undefined) => {
    if (v === undefined || isNaN(v)) return '—';
    let val = state.unit === 'in' ? v / 2.54 : v;
    let unitSym = state.unit === 'cm' ? 'سم' : 'إنش';
    return val.toFixed(1) + ' ' + unitSym;
  };

  const getDetailedValues = () => [
    meas.backWidth, meas.shoulder, meas.backLength, meas.sleeveLength, meas.armCirc, meas.cuffCirc, meas.neckCirc, meas.bust ?? meas.chest, meas.waist, meas.hip, meas.waistToHip, meas.waistToKnee, meas.legLength, meas.skirtLength, meas.chestLength, meas.armholeCirc, meas.waistToArmpit, meas.shoulderToBust ?? meas.shoulderToChest, meas.bustPointDist ?? meas.chestPointDist, meas.thighCirc, meas.kneeCirc, meas.ankleCirc, meas.crotchHeight, meas.sideLength
  ];

  const exportToExcel = () => {
    let detailedValues = getDetailedValues();
    let detailedData = [["#", "القياس", `القيمة (${state.unit === 'cm' ? 'سم' : 'إنش'})`]];
    for (let i = 0; i < detailedNames.length; i++) {
      detailedData.push([String(i + 1), detailedNames[i], formatDim(detailedValues[i])]);
    }
    
    let patternData = [["#", "القياس", "القيمة"]];
    for (let i = 0; i < 37; i++) {
      patternData.push([String(i + 1), patternNames[i], formatDim(patternValues[i])]);
    }
    
    let wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(detailedData), "المقاسات التفصيلية");
    XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(patternData), "مقاسات الباترون الأساسي");
    XLSX.writeFile(wb, `patterns_${state.gender}_${state.size}.xlsx`);
  };

  const handleCopyInstructions = () => {
    const textToCopy = `تعليمات رسم الباترون:
الموديل: ${state.garment} | المدرسة: ${state.school} | القماش: ${state.fabric}
القياسات الأساسية:
- طول الظهر: ${formatDim(patternValues[0])}
- ربع محيط الصدر: ${formatDim(patternValues[11])}
- عمق حردة الإبط: ${formatDim(patternValues[10])}
- ربع محيط الخصر: ${formatDim(patternValues[14])}
- ربع محيط الورك: ${formatDim(patternValues[15])}
بدلات الخياطة:
جانبية ${formatDim(seam.side)}، كتف ${formatDim(seam.shoulder)}، رقبة/إبط ${formatDim(seam.neckArmhole)}، سفلية ${formatDim(seam.hem)}.`;

    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }).catch(() => {});
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-50 p-3 sm:p-4 md:p-8 font-['Tajawal'] transition-colors duration-200" dir="rtl">
      <div className="max-w-7xl mx-auto space-y-6">
        
        {/* Header */}
        <header className="bg-gradient-to-r from-blue-700 via-blue-600 to-indigo-700 dark:from-slate-800 dark:via-blue-950 dark:to-slate-900 text-white p-4 md:p-5 rounded-2xl shadow-xl border border-white/10 flex flex-wrap justify-between items-center gap-4 transition-all">
          <div className="flex items-center gap-3">
            <img 
              src="/icon.svg" 
              alt="أيقونة الباترون" 
              className="w-11 h-11 rounded-xl shadow-lg bg-white/10 p-1 border border-white/20 shrink-0" 
            />
            <div>
              <h1 className="text-xl md:text-2xl font-black tracking-wide flex items-center gap-2">
                موسوعة الأجيال – باترون احترافي
              </h1>
              <p className="text-xs text-blue-100 dark:text-slate-300">نظام ذكي متكامل لتصميم ورسم الباترونات وحساب المقاسات العالمية</p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <button
              onClick={() => setActiveTab('visualizer')}
              className={cn(
                "flex items-center gap-2 px-3.5 py-2 rounded-full transition-all text-xs md:text-sm font-bold shadow-md border active:scale-95",
                activeTab === 'visualizer'
                  ? "bg-amber-400 text-slate-900 border-amber-300 ring-2 ring-amber-300/50"
                  : "bg-white/20 hover:bg-white/30 text-white border-white/20"
              )}
              title="فتح قسم رسم وتعديل الباترون وأدوات الرسم الهندسي"
            >
              <DraftingCompass className={cn("w-4 h-4", activeTab === 'visualizer' ? "text-slate-900" : "text-amber-300")} />
              <span>رسم الباترون (CAD)</span>
            </button>

            <button
              onClick={() => setShowPdfModal(true)}
              className="flex items-center gap-2 px-3.5 py-2 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 active:scale-95 rounded-full transition-all text-xs md:text-sm font-bold text-white shadow-md border border-white/20"
              title="تصدير كارت الباترون والمقاسات كملف PDF"
            >
              <FileText className="w-4 h-4 text-emerald-100" />
              <span>تصدير PDF الشامل</span>
            </button>

            <PWAInstallButton />

            <button 
              onClick={toggleDark} 
              className="flex items-center gap-2 px-3.5 py-2 bg-white/15 hover:bg-white/25 active:bg-white/30 rounded-full transition-all text-xs md:text-sm font-semibold border border-white/20 shadow-sm"
              title={darkMode ? 'التحويل إلى وضع النهار (Light Mode)' : 'التحويل إلى وضع الليل (Dark Mode)'}
              aria-label="تبديل وضع الليل والنهار"
            >
              {darkMode ? (
                <>
                  <Sun className="w-4 h-4 text-amber-300 animate-spin-slow" />
                  <span>الوضع النهاري</span>
                </>
              ) : (
                <>
                  <Moon className="w-4 h-4 text-blue-100" />
                  <span>الوضع الليلي</span>
                </>
              )}
            </button>
          </div>
        </header>

        {/* Settings Panel */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 shadow-sm border border-slate-200 dark:border-slate-700">
          
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4 border-b border-slate-100 dark:border-slate-700 pb-4">
            <h2 className="text-lg font-bold text-blue-700 dark:text-blue-400">إعدادات الباترون</h2>
            <div className="flex bg-slate-100 dark:bg-slate-700 rounded-full p-1">
              <button 
                className={cn("px-4 py-1.5 rounded-full text-sm font-medium transition-colors", !state.useCustomMode ? "bg-blue-600 text-white shadow-sm" : "text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600")}
                onClick={() => updateState({ useCustomMode: false })}
              >
                قياسي (جداول)
              </button>
              <button 
                className={cn("px-4 py-1.5 rounded-full text-sm font-medium transition-colors", state.useCustomMode ? "bg-blue-600 text-white shadow-sm" : "text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600")}
                onClick={() => updateState({ useCustomMode: true })}
              >
                مخصص (إدخال يدوي)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Gender */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">الجنس</label>
              <div className="flex flex-wrap gap-2">
                {[
                  { id: 'women', label: 'نساء' },
                  { id: 'men', label: 'رجال' },
                  { id: 'kids', label: 'أطفال' },
                  { id: 'infant', label: 'رضع' }
                ].map(g => (
                  <button 
                    key={g.id}
                    onClick={() => updateState({ gender: g.id as Gender })}
                    className={cn("px-3 py-1.5 rounded-full text-sm border transition-colors", state.gender === g.id ? "bg-emerald-500 border-emerald-500 text-white" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700")}
                  >
                    {g.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Size System */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">نظام المقاسات</label>
              <select 
                value={state.system} 
                onChange={e => updateState({ system: e.target.value as SizeSystem })}
                className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="eu">🇪🇺 EU</option>
                <option value="us">🇺🇸 US</option>
                <option value="arab">🇸🇦 Arab</option>
                <option value="asian">🇯🇵 Asian</option>
              </select>
            </div>

            {/* Garment Type */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">نوع القطعة (الموديل)</label>
              <select 
                value={state.garment} 
                onChange={e => updateState({ garment: e.target.value as GarmentType })}
                className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <optgroup label="👕 تيشيرتات وبلايز وكاجوال">
                  <option value="tshirt">تيشيرت أساسي قطن (T-Shirt / Camiseta)</option>
                  <option value="polo">قميص بولو بياقة (Polo Shirt)</option>
                  <option value="blouse">بلوزة كلاسيكية (Classic Blouse)</option>
                  <option value="shirt">قميص بأزرار وياقة (Button-up Shirt)</option>
                  <option value="vest">سديري / فيست بدلة (Tailored Vest)</option>
                  <option value="hoodie">هودي / سترة بقبعة (Hoodie)</option>
                </optgroup>
                <optgroup label="👶 أطفال ورضع وملابس نوم">
                  <option value="romper">أفرول / سالوبيت رضيع (Romper / Body Bebê)</option>
                  <option value="pajamas">بيجاما مريحة منزلية (Pajamas Set)</option>
                  <option value="shorts">شورت كاجوال (Casual Shorts)</option>
                </optgroup>
                <optgroup label="👗 فساتين وعبايات ورداء">
                  <option value="dress">فستان كلاسيكي (Dress)</option>
                  <option value="abaya">عباءة خليجية / كيمونو واسع (Abaya)</option>
                  <option value="kimono">كيمونو ياباني / روب لف (Kimono)</option>
                  <option value="cape">كاب / بونشو كلاسيكي (Cape)</option>
                </optgroup>
                <optgroup label="👖 ملابس سفلية وجمبسوت">
                  <option value="pants">بنطلون كلاسيكي (Tailored Pants)</option>
                  <option value="skirt">تنورة مستقيمة (Skirt)</option>
                  <option value="culottes">بنطلون كولوتيس واسع (Culottes)</option>
                  <option value="jumpsuit">جمبسوت عصري (Jumpsuit)</option>
                </optgroup>
                <optgroup label="🧥 سترات ومعاطف">
                  <option value="blazer">بليزر رسمي كلاسيكي (Blazer)</option>
                  <option value="coat">معطف شتوي / ترنش كوت (Coat)</option>
                </optgroup>
              </select>
            </div>

            {/* School */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">مدرسة وطريقة الباترون</label>
              <select 
                value={state.school} 
                onChange={e => updateState({ school: e.target.value as School })}
                className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="mukai">🇧🇷 طريقة مارلين موكاي (Marlene Mukai)</option>
                <option value="italian">🇮🇹 الإيطالية (Sartorial)</option>
                <option value="french">🇫🇷 الفرنسية (ESMOD)</option>
                <option value="german">🇩🇪 الألمانية (M. Müller & Sohn)</option>
                <option value="american">🇺🇸 الأمريكية (Armstrong)</option>
                <option value="arab">🇸🇦 العربية (خليجية/مغاربية)</option>
                <option value="asian">🇯🇵 الآسيوية (Bunka / كورية)</option>
              </select>
            </div>

            {/* Fabric Type */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">نوع القماش</label>
              <select 
                value={state.fabric} 
                onChange={e => updateState({ fabric: e.target.value as FabricType })}
                className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
              >
                <option value="woven">منسوج (Woven) – قطن، كتان، صوف</option>
                <option value="stretchy">مطاطي (Stretchy) – جيرسيه، ليكرا</option>
                <option value="heavy">ثقيل (Heavy) – دنيم، تويد، صوف سميك</option>
                <option value="light">خفيف (Light) – شيفون، حرير، فوال</option>
              </select>
            </div>

            {/* Stretch Percent (Conditional) */}
            {state.fabric === 'stretchy' && (
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">نسبة المطاطية (%)</label>
                <select 
                  value={state.stretchPercent} 
                  onChange={e => updateState({ stretchPercent: parseInt(e.target.value) })}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-600 bg-slate-50 dark:bg-slate-800 focus:ring-2 focus:ring-blue-500 outline-none"
                >
                  <option value="10">10%</option>
                  <option value="15">15%</option>
                  <option value="20">20%</option>
                  <option value="25">25%</option>
                  <option value="30">30%</option>
                </select>
              </div>
            )}

            {/* Seam Allowance */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">بدلات الخياطة</label>
              <div className="flex gap-2">
                <button 
                  onClick={() => updateState({ includeSeam: true })}
                  className={cn("flex-1 py-2 rounded-lg text-sm border transition-colors", state.includeSeam ? "bg-blue-100 dark:bg-blue-900 border-blue-500 text-blue-700 dark:text-blue-300" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-600")}
                >
                  تضمين
                </button>
                <button 
                  onClick={() => updateState({ includeSeam: false })}
                  className={cn("flex-1 py-2 rounded-lg text-sm border transition-colors", !state.includeSeam ? "bg-blue-100 dark:bg-blue-900 border-blue-500 text-blue-700 dark:text-blue-300" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-600")}
                >
                  استبعاد
                </button>
              </div>
            </div>

            {/* Unit */}
            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700 dark:text-slate-300">الوحدة</label>
              <div className="flex gap-2">
                <button 
                  onClick={() => updateState({ unit: 'cm' })}
                  className={cn("flex-1 py-2 rounded-lg text-sm border transition-colors", state.unit === 'cm' ? "bg-blue-100 dark:bg-blue-900 border-blue-500 text-blue-700 dark:text-blue-300" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-600")}
                >
                  سم
                </button>
                <button 
                  onClick={() => updateState({ unit: 'in' })}
                  className={cn("flex-1 py-2 rounded-lg text-sm border transition-colors", state.unit === 'in' ? "bg-blue-100 dark:bg-blue-900 border-blue-500 text-blue-700 dark:text-blue-300" : "bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-600")}
                >
                  إنش
                </button>
              </div>
            </div>
          </div>

          {/* Size Selection (Standard Mode Only) */}
          {!state.useCustomMode && (
            <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-700">
              <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                <label className="text-sm font-bold text-slate-700 dark:text-slate-300">رقم المقاس</label>
                <button
                  onClick={() => setActiveTab('visualizer')}
                  className="flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95"
                >
                  <DraftingCompass className="w-3.5 h-3.5 text-amber-300" />
                  <span>فتح استوديو رسم الباترون ←</span>
                </button>
              </div>
              <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto p-2 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-100 dark:border-slate-700">
                {getSizeList(state.gender).map(s => {
                  let label = mapSizeBySystem(s, state.system, state.gender);
                  if (state.gender === 'infant') {
                    label = `${s} شهر`;
                  } else if (state.gender === 'kids') {
                    label = `${s} سنوات`;
                  }
                  return (
                    <button
                      key={s}
                      onClick={() => updateState({ size: s })}
                      className={cn(
                        "px-4 py-1.5 rounded-full text-sm border transition-colors font-medium",
                        state.size === s 
                          ? "bg-blue-600 border-blue-600 text-white shadow-md" 
                          : "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-600 hover:border-blue-400"
                      )}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Output Tabs */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-700 overflow-hidden">
          <div className="flex border-b border-slate-200 dark:border-slate-700 overflow-x-auto">
            {[
              { id: 'visualizer', label: '✂️ رسم الباترون والأدوات (CAD Studio)' },
              { id: 'measurements', label: '📐 جدول وحاسبة القياسات' },
              { id: 'instructions', label: '📖 خطوات وقواعد التفصيل' }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={cn(
                  "flex-1 min-w-[140px] py-4 text-xs sm:text-sm font-bold transition-colors border-b-2 shrink-0",
                  activeTab === tab.id 
                    ? "border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-900/20" 
                    : "border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50"
                )}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="p-4 sm:p-6">
            {activeTab === 'visualizer' && (
              <div className="space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 bg-slate-100 dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-sm">
                      <DraftingCompass className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-black text-slate-900 dark:text-white">قسم رسم وهندسة الباترون (CAD Studio)</h3>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">مساحة عمل متكاملة مع أدوات الرسم الذكية، المسارات، المنحنيات، والمساطر الرقمية</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setActiveTab('measurements')}
                      className="px-3.5 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 transition-all shadow-xs"
                    >
                      ← العودة إلى جدول القياسات
                    </button>
                  </div>
                </div>

                <PatternVisualizer state={state} onBackToCalculator={() => setActiveTab('measurements')} />
              </div>
            )}
            {activeTab === 'measurements' && (
              <div className="space-y-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Detailed Measurements */}
                  <div>
                    <h3 className="text-lg font-bold mb-4 text-slate-800 dark:text-slate-100 flex items-center gap-2">
                      <span className="w-2 h-6 bg-emerald-500 rounded-full"></span>
                      المقاسات التفصيلية (24 قياساً)
                    </h3>
                    {state.useCustomMode && (
                      <div className="mb-4 flex justify-end">
                        <button 
                          onClick={() => updateState({ customMeasurements: {} })}
                          className="flex items-center gap-2 text-sm text-red-500 hover:text-red-600 font-medium"
                        >
                          <RotateCcw className="w-4 h-4" /> إعادة تعيين
                        </button>
                      </div>
                    )}
                    <div className="bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
                      <ul className="divide-y divide-slate-200 dark:divide-slate-700">
                        {detailedNames.map((name, i) => {
                          const val = getDetailedValues()[i];
                          const key = [
                            "backWidth", "shoulder", "backLength", "sleeveLength", "armCirc", "cuffCirc", "neckCirc", "bust", "waist", "hip", "waistToHip", "waistToKnee", "legLength", "skirtLength", "chestLength", "armholeCirc", "waistToArmpit", "shoulderToBust", "bustPointDist", "thighCirc", "kneeCirc", "ankleCirc", "crotchHeight", "sideLength"
                          ][i];
                          
                          return (
                            <li key={i} className="flex justify-between items-center p-3 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                              <span className="text-sm font-medium text-slate-700 dark:text-slate-300 flex items-center gap-2">
                                {i + 1}. {name}
                                <button title={detailedHelps[i]} className="text-blue-500 hover:text-blue-700"><Info className="w-4 h-4" /></button>
                              </span>
                              {state.useCustomMode ? (
                                <input 
                                  type="number" 
                                  value={state.customMeasurements[key] ?? val ?? ''}
                                  onChange={(e) => {
                                    const num = parseFloat(e.target.value);
                                    updateState({
                                      customMeasurements: {
                                        ...state.customMeasurements,
                                        [key]: isNaN(num) ? 0 : num
                                      }
                                    });
                                  }}
                                  className="w-24 text-left font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-800 px-3 py-1 rounded-md border border-slate-300 dark:border-slate-600 shadow-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                  dir="ltr"
                                />
                              ) : (
                                <span className="font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-800 px-3 py-1 rounded-md border border-slate-200 dark:border-slate-600 shadow-sm text-left min-w-[80px]" dir="ltr">
                                  {formatDim(val)}
                                </span>
                              )}
                            </li>
                          );
                        })}
                      </ul>
                    </div>
                  </div>

                  {/* Pattern Measurements */}
                  <div>
                    <h3 className="text-lg font-bold mb-4 text-slate-800 dark:text-slate-100 flex items-center gap-2">
                      <span className="w-2 h-6 bg-blue-600 rounded-full"></span>
                      مقاسات الباترون الأساسي (ربع القالب)
                    </h3>
                    <div className="bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
                      <ul className="divide-y divide-slate-200 dark:divide-slate-700">
                        {patternNames.map((name, i) => (
                          <li key={i} className="flex justify-between items-center p-3 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors">
                            <span className="text-sm font-medium text-blue-700 dark:text-blue-400">
                              {i + 1}. {name}
                            </span>
                            <span className="font-bold text-slate-900 dark:text-white bg-white dark:bg-slate-800 px-3 py-1 rounded-md border border-slate-200 dark:border-slate-600 shadow-sm text-left min-w-[80px]">
                              {formatDim(patternValues[i])}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'instructions' && (
              <div className="prose prose-slate dark:prose-invert max-w-none">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="text-xl font-bold m-0 text-slate-900 dark:text-slate-100">تعليمات رسم الباترون – دليل تفصيلي</h3>
                  <button 
                    onClick={handleCopyInstructions}
                    className="flex items-center gap-2 px-4 py-2 bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 rounded-lg transition-colors text-sm font-semibold text-slate-700 dark:text-slate-200 shadow-xs active:scale-95"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 text-emerald-500" />
                        <span className="text-emerald-600 dark:text-emerald-400">تم النسخ بنجاح!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                        <span>نسخ التعليمات</span>
                      </>
                    )}
                  </button>
                </div>
                
                <div className="bg-slate-50 dark:bg-slate-900 p-6 rounded-xl border border-slate-200 dark:border-slate-700">
                  <h4 className="text-blue-600 dark:text-blue-400 mt-0 font-bold">التحضير</h4>
                  <ul className="text-slate-700 dark:text-slate-300">
                    <li>ورق باترون، مسطرة طويلة، مثلث، قلم رصاص، مسطرة منحنيات فرنسية.</li>
                    <li>المدرسة: <strong>{state.school}</strong> | القماش: <strong>{state.fabric}</strong> | الموديل: <strong>{state.garment}</strong></li>
                    <li>زيادات الخياطة: جانبية {formatDim(seam.side)}، كتف {formatDim(seam.shoulder)}، رقبة/إبط {formatDim(seam.neckArmhole)}، سفلية {formatDim(seam.hem)}.</li>
                  </ul>

                  {['blouse', 'dress', 'abaya', 'coat', 'jumpsuit', 'shirt', 'vest', 'hoodie', 'blazer', 'kimono', 'cape'].includes(state.garment) && (
                    <>
                      <h4 className="text-blue-600 dark:text-blue-400 font-bold">الجزء العلوي</h4>
                      <p className="text-slate-700 dark:text-slate-300"><strong>1. المستطيل الأساسي:</strong> العرض = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[11])}</span>، الارتفاع = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[0])}</span>.</p>
                      <p className="text-slate-700 dark:text-slate-300"><strong>2. خطوط الإرشاد:</strong> خط الصدر أسفل بمقدار <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[10])}</span>.</p>
                      <p className="text-slate-700 dark:text-slate-300"><strong>3. حردة الرقبة:</strong> عرض = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[5])}</span>، نزول أمامي = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[7])}</span>، نزول خلفي = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[8])}</span>.</p>
                      <p className="text-slate-700 dark:text-slate-300"><strong>4. خط الكتف:</strong> طول = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[2])}</span>، ميلان = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[3])}</span>.</p>
                    </>
                  )}
                  
                  {['pants', 'skirt', 'jumpsuit', 'culottes'].includes(state.garment) && (
                    <>
                      <h4 className="text-blue-600 dark:text-blue-400 font-bold">الجزء السفلي</h4>
                      <p className="text-slate-700 dark:text-slate-300"><strong>1. المستطيل الأساسي:</strong> العرض = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[15])}</span>، الارتفاع = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[20])}</span>.</p>
                      <p className="text-slate-700 dark:text-slate-300"><strong>2. خط الورك:</strong> أسفل الخصر بمقدار <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[16])}</span>.</p>
                      {['pants', 'jumpsuit', 'culottes'].includes(state.garment) && (
                        <p className="text-slate-700 dark:text-slate-300"><strong>3. خط السرج:</strong> أسفل الخصر بمقدار <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[25])}</span>. عرض السرج الأمامي = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[26])}</span>، الخلفي = <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[27])}</span>.</p>
                      )}
                    </>
                  )}

                  {['dress', 'abaya', 'coat', 'kimono', 'cape'].includes(state.garment) && (
                    <>
                      <h4 className="text-blue-600 dark:text-blue-400 font-bold">امتداد الطول</h4>
                      <p className="text-slate-700 dark:text-slate-300"><strong>1. الطول الكلي:</strong> امتداد من خط الخصر إلى أسفل بمقدار <span className="bg-yellow-100 dark:bg-amber-950/60 text-yellow-900 dark:text-amber-200 px-1.5 py-0.5 rounded font-mono font-semibold border border-yellow-300/60 dark:border-amber-700/60">{formatDim(patternValues[21])}</span>.</p>
                      <p className="text-slate-700 dark:text-slate-300"><strong>2. التوسيع:</strong> أضف توسيعاً من خط الجنب عند الذيل بمقدار 10-20 سم حسب الموديل.</p>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Export Button */}
        <div className="flex justify-center pt-4">
          <button 
            onClick={exportToExcel}
            className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-full font-bold shadow-lg transition-all hover:scale-105 active:scale-95"
          >
            <FileSpreadsheet className="w-5 h-5" />
            تصدير Excel (القياسات التفصيلية + الباترون)
          </button>
        </div>

      </div>

      {/* PDF Specification Card Modal Export */}
      <PdfExportModal
        state={state}
        isOpen={showPdfModal}
        onClose={() => setShowPdfModal(false)}
      />

      {/* Offline Status Toast Indicator */}
      <OfflineIndicator />
    </div>
  );
}
